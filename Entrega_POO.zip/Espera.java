package projetopoo;

/**
 *
 * @author Gabriel
 */
public class Espera extends Reserva {
    Espera(Viagem v){
        super(v,0,0);
    }


}
