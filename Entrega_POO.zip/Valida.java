package projetopoo;


/**
 *
 * @author Gabriel
 */
public class Valida extends Reserva{
    Valida(Viagem v, int lugar, double valor){
        super(v,lugar,valor);
    }
}
